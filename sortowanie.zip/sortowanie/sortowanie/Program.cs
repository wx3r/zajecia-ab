﻿using System.ComponentModel.DataAnnotations;

class Program 
{
    static void Bubble(int[] tab)
    {
        int n = tab.Length;
        for (int i = 0; i < n; i++)
        {
            for (int j = 1; j< n-i; j++)
            {
                if (tab[j -1] > tab[j])
                {
                    int temp = tab[j-1];
                    tab[j-1] = tab[j];
                    tab[j] = temp;
                }
            }
        }
    }
    static void Main(string[] args)
    {
        Console.WriteLine("Ile liczb chcesz posortować?");
        int n = int.Parse(Console.ReadLine());
        int[] tab = new int[n];
        Console.WriteLine("Podaj liczby: ");
        for (int i = 0;i < n; i++)
        {
            tab[i] = int.Parse(Console.ReadLine());
        }
        Bubble(tab);
        Console.WriteLine("Posortowane liczby");
        foreach(var lizcba in tab)
        {
            Console.WriteLine(lizcba + " ");
        }
        Console.ReadLine();
    }
}