﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powtorzenie
{
    public class Klient : Osoba
    {
        public List<IProdukt> Koszyk { get; set; } = new List<IProdukt>();
        public void DodajDoKoszyka(IProdukt produkt, int ilosc)
        {
            if (produkt.Dostepnosc() >= ilosc)
            {
                for (int i = 0; i < ilosc; i++)
                {
                    Koszyk.Add(produkt);
                }
                Console.WriteLine($"{ilosc} sztuk {produkt.GetType().Name} dodano do koszyka.");
            }
            else
            {
                Console.WriteLine($"Brak wystarczającej ilości {produkt.GetType().Name} na stanie.");
            }
        }
        public void WyswietlCeneProduktu(IProdukt produkt)
        {
            Console.WriteLine($"Cena {produkt.GetType().Name}: {produkt.AktualnaCena()}");
        }

        public void ObliczKosztKoszyka()
        {
            decimal koszt = Koszyk.Sum(p => p.AktualnaCena());
            Console.WriteLine($"Koszt całego koszyka: {koszt}");
        }
    }
}