﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powtorzenie
{
    public class Ksiazka : Produkt
    {
        public override decimal AktualnaCena()
        {
            return Cena * 0.9M; //ksiaka ma 10% zniżki w cenie aktualnej
        }
    }
}