﻿namespace powtorzenie
{
    class Program
    {
        static void Main(string[] args)
        {
            Ksiazka ksiazka = new Ksiazka { Cena = 30, IloscDostepna = 50, Opis = "Bestseller" };
            Elektronika elektronika = new Elektronika { Cena = 1000, IloscDostepna = 10, Opis = "Smartphone" };
            Odziez odziez = new Odziez { Cena = 50, IloscDostepna = 100, Opis = "T-shirt" };

            Klient klient = new Klient { Imie = "Jan", Nazwisko = "Kowalski" };

            klient.DodajDoKoszyka(ksiazka, 2);
            klient.DodajDoKoszyka(elektronika, 1);
            klient.DodajDoKoszyka(odziez, 3);

            Console.WriteLine("\nZawartość koszyka:");
            foreach (var produkt in klient.Koszyk)
            {
                produkt.WyswietlInfo();
            }

            Console.WriteLine("\nCeny produktów:");
            foreach (var produkt in klient.Koszyk)
            {
                klient.WyswietlCeneProduktu(produkt);
            }

            Console.WriteLine("\nKoszt całego koszyka:");
            klient.ObliczKosztKoszyka();
        }
    }
}