﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powtorzenie
{
    public class Odziez : Produkt
    {
        public override decimal AktualnaCena()
        {
            return Cena;
        }
    }
}