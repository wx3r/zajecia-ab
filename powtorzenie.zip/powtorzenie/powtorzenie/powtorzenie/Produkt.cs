﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powtorzenie
{
    public class Produkt : IProdukt
    {
        public decimal Cena { get; set; }
        public int IloscDostepna { get; set; }
        public string Opis { get; set; }

        public void WyswietlInfo()
        {
            Console.WriteLine($"Opis: {Opis}, Cena: {Cena}, Dostępność: {IloscDostepna}");
        }
        public virtual decimal AktualnaCena()
        {
            return Cena;
        }
        public int Dostepnosc()
        {
            return IloscDostepna;
        }
    }
}