﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powtorzenie
{
    public interface IProdukt
    {
        void WyswietlInfo();
        decimal AktualnaCena();
        int Dostepnosc();
    }
}
